const express = require('express');
const router = express.Router();

const items = [
  { id: 1, name: 'Eemento en lista 1 (TO-DO)' },
  { id: 2, name: 'Eemento en lista 2 (TO-DO)' },
  { id: 3, name: 'Eemento en lista 3 (TO-DO)' }
];

router.get('/', (req, res) => {
  res.render('index', { title: 'Página Inicial', items });
});

module.exports = router;
